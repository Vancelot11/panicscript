# panicscript
CS381 Language

## Team Members
- Kerry Vance

## To Run:
runProg ex1 shows a simple loop to 100

runProg ex2 shows implementation of example code in Design doc

runProg exFor shows implementation of for loop
